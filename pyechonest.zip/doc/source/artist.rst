Artist -- artist methods
=========================

.. autoclass:: pyechonest.artist.Artist
   :members:

.. automethod:: pyechonest.artist.search 

.. automethod:: pyechonest.artist.top_hottt 

.. automethod:: pyechonest.artist.top_terms 

.. automethod:: pyechonest.artist.similar