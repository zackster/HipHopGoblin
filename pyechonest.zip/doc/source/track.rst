Track -- track methods
=========================

.. autoclass:: pyechonest.track.Track
   :members:

.. automethod:: pyechonest.track.track_from_file

.. automethod:: pyechonest.track.track_from_filename

.. automethod:: pyechonest.track.track_from_url

.. automethod:: pyechonest.track.track_from_id

.. automethod:: pyechonest.track.track_from_md5

.. automethod:: pyechonest.track.track_from_reanalyzing_md5

