Playlist -- playlist methods
============================

.. autoclass:: pyechonest.playlist.Playlist
   :members:

.. automethod:: pyechonest.playlist.static 
