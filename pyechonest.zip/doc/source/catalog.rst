Catalog -- catalog methods
==========================

.. autoclass:: pyechonest.catalog.Catalog
   :members:

.. automethod:: pyechonest.catalog.list 

