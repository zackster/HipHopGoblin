Song -- song methods
=========================

.. autoclass:: pyechonest.song.Song
   :members:

.. automethod:: pyechonest.song.identify
                           
.. automethod:: pyechonest.song.search
                           
.. automethod:: pyechonest.song.profile